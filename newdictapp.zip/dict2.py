import json
from difflib import get_close_matches
data1 = json.load(open("data1.json","r"))
def translate(word):
    word = word.lower()
    if word in data1:
        return data1[word]
    elif len(get_close_matches(word, data1.keys())) > 0:
        yn = input("Did you mean %s instead?\nEnter yes if your word is in the list appeared,\nor no if not:\n " % get_close_matches(word, data1.keys())[0:4])
        if yn =="yes":
            nw=int(input("Enter the sequence number of the desired word appeared in the list out of 1-!3: "))
            nw=nw-1
            return data1[get_close_matches(word, data1.keys()) [nw]]

                         

        elif yn =="no":
            return "The word dosen't exists.Please do correct the spelling . Or report for any kind of extra error found. Thank you"
        else:
            return "We didn't get your entry.Check again"
    else:
        return "please check the spelling"
word = input("enter a word: ")
output =translate(word)
if type(output) == list:
    for item in output:
        print(item)
else:
    print(output)
